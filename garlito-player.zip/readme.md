# Garlito Player Wordpress Plugin

Garlito is a simple shoutcast & icecast web radio player.

## Installation

Copy the folder into wp-content/plugins


## Preview of the player

![App Screenshot](https://boheme-radio.com/wp-content/uploads/2021/09/playerr.png)

  